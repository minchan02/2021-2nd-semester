package millenium.c21;

/**
  This class's name is PPoint
  you can get x, y
 */
public class PPoint {
    int xA;
    int yA;
    
    public PPoint(int x, int y) {
        xA = x;
        yA = y;
    };
    
    /**
	    @param xA is x, yA is y
	    get x 
    */
    public int getX() {
        return xA;
    } 
    public int getY() {
        return yA;
    } 
}
