import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Buffer {
	public static void main(String[] args) throws IOException {
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		String arr = "";
		
		while(!arr.equals("quit")) {
			try {
				arr = in.readLine();
				System.out.println(arr);
			}
			
			catch(IOException e1) {
				System.out.println(e1);
			}
			
		}
	}
}
